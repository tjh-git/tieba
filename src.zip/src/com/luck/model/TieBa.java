package com.luck.model;

public class TieBa  
{
	private String name;
	private String ids;
	private boolean show=false;
	public boolean isShow() 
	{
		return show;
	}
	public void setShow(boolean show) 
	{
		this.show = show;
	}
	public String getIds() 
	{
		return ids;
	}
	public void setIds(String ids) 
	{
		this.ids = ids;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
}
