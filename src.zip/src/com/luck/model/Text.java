package com.luck.model;

public class Text
{
	public static void main(String[] args) 
	{
		User user=new User();
		user.setId(12);
		user.setLove("123");
		user.setName("�׽�");
		user.setPassword("123456");
		user.setPath("4465465");
		user.check();
	}
}
