package com.luck.util;
import java.util.*;
public class Check 
{
	
}
